#ifndef __BT_APP_GAP_H__
#define __BT_APP_GAP_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void bt_app_gap_start_up(void);
void bt_app_gap_pre_init(void);

static uint8_t searched_devices[10][6];
static int num_searched_devices = 0;

void print_devices();

void start_wifi_server();

#endif