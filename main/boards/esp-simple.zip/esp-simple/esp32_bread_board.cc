#include "wifi_board.h"
#include "ml307_board.h"
#include "system_reset.h"
#include "audio_codecs/bt_audio_codec.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "iot/thing_manager.h"
#include "led/single_led.h"
#include "display/ssd1306_display.h"
#include "display/no_display.h"
#include <wifi_station.h>
#include <esp_log.h>
#include <driver/i2c_master.h>

#include "app_hf_msg_set.h"
#include "esp_system.h"
#include "esp_bt.h"
#include "bt_app_core.h"
#include "esp_bt_main.h"
#include "esp_bt_device.h"
#include "esp_hf_ag_api.h"
#include "bt_app_hf.h"
#include "esp_gap_bt_api.h"
#include "gpio_pcm_config.h"
#include "esp_console.h"
#include <stdint.h>
#include <string.h>
#include <inttypes.h>

#include "bt_app_gap.h"

#define TAG "ESP32-SimpleSupport"

LV_FONT_DECLARE(font_puhui_14_1);
LV_FONT_DECLARE(font_awesome_14_1);

/* event for handler "bt_av_hdl_stack_up */
enum
{
    BT_APP_EVT_STACK_UP = 0,
};

static char *bda2str(esp_bd_addr_t bda, char *str, size_t size)
{
    if (bda == NULL || str == NULL || size < 18)
    {
        return NULL;
    }

    uint8_t *p = bda;
    sprintf(str, "%02x:%02x:%02x:%02x:%02x:%02x",
            p[0], p[1], p[2], p[3], p[4], p[5]);
    return str;
}

static void bt_hf_hdl_stack_evt(uint16_t event, void *p_param)
{
    ESP_LOGD(BT_HF_TAG, "%s evt %d", __func__, event);
    switch (event)
    {
    case BT_APP_EVT_STACK_UP:
    {
        /* set up device name */
        char *dev_name = "ESP_HFP_AG";
        esp_bt_gap_set_device_name(dev_name);

        esp_hf_ag_register_callback(bt_app_hf_cb);

        // init and register for HFP_AG functions
        esp_hf_ag_init();

        /*
         * Set default parameters for Legacy Pairing
         * Use variable pin, input pin code when pairing
         */
        esp_bt_pin_type_t pin_type = ESP_BT_PIN_TYPE_VARIABLE;
        esp_bt_pin_code_t pin_code;
        pin_code[0] = '0';
        pin_code[1] = '0';
        pin_code[2] = '0';
        pin_code[3] = '0';
        esp_bt_gap_set_pin(pin_type, 4, pin_code);

        /* set discoverable and connectable mode, wait to be connected */
        esp_bt_gap_set_scan_mode(ESP_BT_CONNECTABLE, ESP_BT_GENERAL_DISCOVERABLE);
        break;
    }
    default:
        ESP_LOGE(BT_HF_TAG, "%s unhandled evt %d", __func__, event);
        break;
    }
}

char bda_str[18] = {0};

class EspSimpleMl307Board : public Ml307Board
{
private:
    i2c_master_bus_handle_t display_i2c_bus_;
    Button boot_button_;
    Button touch_button_;

    void InitializeDisplayI2c()
    {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &display_i2c_bus_));
    }

    void InitializeButtons()
    {
        boot_button_.OnClick([this]()
                             { Application::GetInstance().ToggleChatState(); });
        touch_button_.OnPressDown([this]()
                                  { Application::GetInstance().StartListening(); });
        touch_button_.OnPressUp([this]()
                                { Application::GetInstance().StopListening(); });
    }

    // 物联网初始化，添加对 AI 可见设备
    void InitializeIot()
    {
        auto &thing_manager = iot::ThingManager::GetInstance();
        thing_manager.AddThing(iot::CreateThing("Speaker"));
        thing_manager.AddThing(iot::CreateThing("Lamp"));
    }

public:
    EspSimpleMl307Board() : Ml307Board(ML307_TX_PIN, ML307_RX_PIN, 4096),
                            boot_button_(BOOT_BUTTON_GPIO),
                            touch_button_(TOUCH_BUTTON_GPIO)
    {

        InitializeDisplayI2c();
        InitializeButtons();
        // InitializeIot();
    }

    virtual Led *GetLed() override
    {
        static SingleLed led(BUILTIN_LED_GPIO);
        return &led;
    }

    virtual AudioCodec *GetAudioCodec() override
    {
        // #ifdef AUDIO_I2S_METHOD_SIMPLEX
        //         static NoAudioCodecSimplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
        //                                                AUDIO_I2S_SPK_GPIO_BCLK, AUDIO_I2S_SPK_GPIO_LRCK, AUDIO_I2S_SPK_GPIO_DOUT, AUDIO_I2S_MIC_GPIO_SCK, AUDIO_I2S_MIC_GPIO_WS, AUDIO_I2S_MIC_GPIO_DIN);
        // #else
        //         static NoAudioCodecDuplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
        //                                               AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS, AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN);
        // #endif

        static BtAudioCodec *audio_codec = new BtAudioCodec();
        return audio_codec;
    }

    virtual Display *GetDisplay() override
    {
        static Ssd1306Display display(display_i2c_bus_, DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y,
                                      &font_puhui_14_1, &font_awesome_14_1);
        return &display;
    }
};

class EspSimpleWifiBoard : public WifiBoard
{
private:
    Button boot_button_;
    Button touch_button_;
    Button asr_button_;
    NoDisplay *display_;

    BtAudioCodec *audio_codec = new BtAudioCodec();

    i2c_master_bus_handle_t display_i2c_bus_;

    void InitializeDisplayI2c()
    {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &display_i2c_bus_));
    }
    void InitializeNoDisplay()
    {
        display_ = new NoDisplay();
    }

    void InitializeButtons()
    {

        // 配置 GPIO
        gpio_config_t io_conf = {
            .pin_bit_mask = 1ULL << BUILTIN_LED_GPIO, // 设置需要配置的 GPIO 引脚
            .mode = GPIO_MODE_OUTPUT,                 // 设置为输出模式
            .pull_up_en = GPIO_PULLUP_DISABLE,        // 禁用上拉
            .pull_down_en = GPIO_PULLDOWN_DISABLE,    // 禁用下拉
            .intr_type = GPIO_INTR_DISABLE            // 禁用中断
        };
        gpio_config(&io_conf); // 应用配置

        boot_button_.OnClick([this]()
                             {
            ESP_LOGI(TAG, "boot button clicked");                   
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting && !WifiStation::GetInstance().IsConnected()) {
                ResetWifiConfiguration();
            }
            gpio_set_level(BUILTIN_LED_GPIO, 1);
            app.ToggleChatState(); });

        asr_button_.OnClick([this]()
                            {
            ESP_LOGI(TAG, "asr button clicked");
            std::string wake_word="你好小智";
            Application::GetInstance().WakeWordInvoke(wake_word); });

        touch_button_.OnPressDown([this]()
                                  {
            gpio_set_level(BUILTIN_LED_GPIO, 1);
            Application::GetInstance().StartListening(); });
        touch_button_.OnPressUp([this]()
                                {
            gpio_set_level(BUILTIN_LED_GPIO, 0);
            Application::GetInstance().StopListening(); });
    }

    // 物联网初始化，添加对 AI 可见设备
    void InitializeIot()
    {
        auto &thing_manager = iot::ThingManager::GetInstance();
        thing_manager.AddThing(iot::CreateThing("Speaker"));
        thing_manager.AddThing(iot::CreateThing("Lamp"));
    }

public:
    EspSimpleWifiBoard() : boot_button_(BOOT_BUTTON_GPIO), touch_button_(TOUCH_BUTTON_GPIO), asr_button_(ASR_BUTTON_GPIO)
    {

        // bt_app_gap_pre_init();
        // bt_app_gap_start_up();
        InitializeDisplayI2c();
        InitializeNoDisplay();
        InitializeButtons();
        // return ;

        esp_err_t ret;

        ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_BLE));

        esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
        if ((ret = esp_bt_controller_init(&bt_cfg)) != ESP_OK)
        {
            ESP_LOGE(BT_HF_TAG, "%s initialize controller failed: %s", __func__, esp_err_to_name(ret));
            return;
        }
        if ((ret = esp_bt_controller_enable(ESP_BT_MODE_CLASSIC_BT)) != ESP_OK)
        {
            ESP_LOGE(BT_HF_TAG, "%s enable controller failed: %s", __func__, esp_err_to_name(ret));
            return;
        }
        esp_bluedroid_config_t bluedroid_cfg = BT_BLUEDROID_INIT_CONFIG_DEFAULT();
        if ((ret = esp_bluedroid_init_with_cfg(&bluedroid_cfg)) != ESP_OK)
        {
            ESP_LOGE(BT_HF_TAG, "%s initialize bluedroid failed: %s", __func__, esp_err_to_name(ret));
            return;
        }
        if ((ret = esp_bluedroid_enable()) != ESP_OK)
        {
            ESP_LOGE(BT_HF_TAG, "%s enable bluedroid failed: %s", __func__, esp_err_to_name(ret));
            return;
        }

        ESP_LOGI(BT_HF_TAG, "Own address:[%s]", bda2str((uint8_t *)esp_bt_dev_get_address(), bda_str, sizeof(bda_str)));

        print_devices();

        /* create application task */
        bt_app_task_start_up();

        /* Bluetooth device name, connection mode and profile set up */
        bt_app_work_dispatch(bt_hf_hdl_stack_evt, BT_APP_EVT_STACK_UP, NULL, 0, NULL);

        esp_console_repl_t *repl = NULL;
        esp_console_repl_config_t repl_config = ESP_CONSOLE_REPL_CONFIG_DEFAULT();
        esp_console_dev_uart_config_t uart_config = ESP_CONSOLE_DEV_UART_CONFIG_DEFAULT();
        repl_config.prompt = "hfp_ag>";

        // init console REPL environment
        ESP_ERROR_CHECK(esp_console_new_repl_uart(&uart_config, &repl_config, &repl));

        /* Register commands */
        register_hfp_ag();

        // start console REPL
        ESP_ERROR_CHECK(esp_console_start_repl(repl));
    }

    virtual AudioCodec *GetAudioCodec() override
    {
        // #ifdef AUDIO_I2S_METHOD_SIMPLEX
        //         static NoAudioCodecSimplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
        //                                                AUDIO_I2S_SPK_GPIO_BCLK, AUDIO_I2S_SPK_GPIO_LRCK, AUDIO_I2S_SPK_GPIO_DOUT, AUDIO_I2S_MIC_GPIO_SCK, AUDIO_I2S_MIC_GPIO_WS, AUDIO_I2S_MIC_GPIO_DIN);
        // #else
        //         static NoAudioCodecDuplex audio_codec(AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
        //                                               AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS, AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN);
        // #endif

        if (audio_codec == nullptr)
        {
            ESP_LOGI(TAG, "audio_codec is nullptr");
            audio_codec = new BtAudioCodec();
        }
        return audio_codec;
    }

    // virtual Display* GetDisplay() override {
    //     static Ssd1306Display display(display_i2c_bus_, DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y,
    //                                 &font_puhui_14_1, &font_awesome_14_1);
    //     return &display;
    // }
    virtual Display *GetDisplay() override
    {
        return display_;
    }
};

DECLARE_BOARD(EspSimpleWifiBoard);
